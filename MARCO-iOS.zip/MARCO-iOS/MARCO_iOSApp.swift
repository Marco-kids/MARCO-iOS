//
//  MARCO_iOSApp.swift
//  MARCO-iOS
//
//  Created by Jose Castillo on 10/12/22.
//

import SwiftUI

@main
struct MARCO_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
